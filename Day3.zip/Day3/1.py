keys = ['Ten', 'Twenty', 'Thirty']
values = [10, 20, 30]

dictionary = {k: v for k, v in zip(keys, values)}
print(dictionary)
